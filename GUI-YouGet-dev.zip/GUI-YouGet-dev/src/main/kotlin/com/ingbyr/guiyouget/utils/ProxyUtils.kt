package com.ingbyr.guiyouget.utils

enum class ProxyType {
    PROXY_TYPE,
    SOCKS5,
    HTTP,
    SOCKS5_PROXY_ADDRESS,
    SOCKS5_PROXY_PORT,
    HTTP_PROXY_ADDRESS,
    HTTP_PROXY_PORT,
    NONE
}

