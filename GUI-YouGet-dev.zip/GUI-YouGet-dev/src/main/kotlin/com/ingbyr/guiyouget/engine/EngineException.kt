package com.ingbyr.guiyouget.engine

class DownloadEngineException(message: String) : Exception(message)